def read_file(path, **kwargs):
    with open(path, "r") as f:
        return f.read()

def write_file(path, content, **kwargs):
    with open(path, "w") as f:
        f.write(content)
    return "OK"
