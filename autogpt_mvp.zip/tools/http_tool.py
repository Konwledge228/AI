import requests

def http_get(url, **kwargs):
    return requests.get(url, timeout=3).text[:1000]
