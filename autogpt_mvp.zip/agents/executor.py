import json

class Executor:
    def __init__(self, registry):
        self.registry = registry

    def execute(self, plan_str):
        try:
            plan = json.loads(plan_str)
        except:
            return "Invalid JSON plan"

        tool = self.registry.get(plan["tool"])
        if not tool:
            return f"Tool not found: {plan['tool']}"

        return tool(**plan.get("args", {}))
