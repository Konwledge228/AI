class Memory:
    def __init__(self):
        self.history = []

    def add(self, item):
        self.history.append(item)

    def summary(self):
        return "\n".join(str(x) for x in self.history[-5:])
