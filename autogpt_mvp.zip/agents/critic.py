from llm.client import chat

def critique(goal, result):
    prompt = f'''
目标:
{goal}

执行结果:
{result}

请判断：
1. 是否完成目标（yes/no）
2. 如果没有，下一步建议

JSON:
{{
 "done": true/false,
 "next": "..."
}}
'''
    return chat(prompt)
