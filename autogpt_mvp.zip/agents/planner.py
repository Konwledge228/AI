from llm.client import chat

def plan(goal, memory):
    prompt = f'''
你是一个AI任务规划器。

目标:
{goal}

历史:
{memory.summary()}

请输出下一步行动，JSON格式：
{{
 "tool": "...",
 "args": {{...}},
 "reason": "为什么这么做"
}}
'''
    return chat(prompt)
