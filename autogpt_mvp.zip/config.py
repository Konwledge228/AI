OPENAI_API_KEY = "your-key"
MODEL = "gpt-4o-mini"
MAX_ITER = 5
