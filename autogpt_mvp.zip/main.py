from agents.memory import Memory
from agents.planner import plan
from agents.executor import Executor
from agents.critic import critique

from tools.registry import ToolRegistry
from tools.file_tool import read_file, write_file
from tools.http_tool import http_get

from executor.python_exec import run_python
from executor.bash_exec import run_bash

import json
from config import MAX_ITER

def build_registry():
    r = ToolRegistry()
    r.register("python", run_python)
    r.register("bash", run_bash)
    r.register("read_file", read_file)
    r.register("write_file", write_file)
    r.register("http_get", http_get)
    return r

def main():
    goal = "写一个文件 hello.txt 内容为 Hello AutoGPT"

    memory = Memory()
    registry = build_registry()
    executor = Executor(registry)

    for i in range(MAX_ITER):
        print(f"\n=== ITER {i} ===")

        plan_str = plan(goal, memory)
        print("PLAN:", plan_str)

        result = executor.execute(plan_str)
        print("RESULT:", result)

        memory.add((plan_str, result))

        critique_str = critique(goal, result)
        print("CRITIC:", critique_str)

        try:
            c = json.loads(critique_str)
            if c.get("done"):
                print("DONE")
                break
        except:
            pass

if __name__ == "__main__":
    main()
