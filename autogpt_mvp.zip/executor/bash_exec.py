import subprocess

def run_bash(command, **kwargs):
    try:
        out = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=5
        )
        return out.stdout or out.stderr
    except:
        return "error"
