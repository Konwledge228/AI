import subprocess, tempfile

def run_python(code, **kwargs):
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(code)
        fname = f.name

    try:
        out = subprocess.run(
            ["python", fname],
            capture_output=True,
            text=True,
            timeout=5
        )
        return out.stdout or out.stderr
    except:
        return "error"
