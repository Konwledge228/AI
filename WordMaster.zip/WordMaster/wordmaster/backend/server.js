// server.js - 后端主入口
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { db, initDB } = require('./db');
const { cacheMiddleware, clearCacheAfterChange } = require('./cache-helper');

const app = express();
const PORT = process.env.PORT || 3000;

// CORS 配置 - 允许所有来源（开发环境）
const corsOptions = {
  origin: function (origin, callback) {
    // 允许没有origin的请求（如curl、postman等）
    // 或者允许来自 localhost 的任何端口
    if (!origin || origin.includes('localhost') || origin.includes('127.0.0.1')) {
      callback(null, true);
    } else {
      callback(null, true); // 开发环境暂时允许所有来源
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 初始化数据库
initDB();

// 静态文件（前端）
app.use(express.static(__dirname + '/../frontend'));

// 路由（带缓存）
app.use('/api/words', cacheMiddleware, require('./routes/words'));
app.use('/api/stats', cacheMiddleware, require('./routes/stats'));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/study', clearCacheAfterChange('words'), require('./routes/study'));
app.use('/api/review', clearCacheAfterChange('words'), require('./routes/review'));

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 404
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// 错误处理
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Server error', message: err.message });
});

app.listen(PORT, () => {
  console.log(`WordMaster backend running on http://localhost:${PORT}`);
});
