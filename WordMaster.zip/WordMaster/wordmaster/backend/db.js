// db.js - SQLite 数据库初始化
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'data', 'wordmaster.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) console.error('DB connection error:', err);
  else console.log('Connected to SQLite DB at', dbPath);
});

// 初始化所有表
function initDB() {
  db.serialize(() => {
    // 用户表
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        avatar TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 单词表
    db.run(`
      CREATE TABLE IF NOT EXISTS words (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        word TEXT NOT NULL,
        phonetic TEXT,
        meaning_cn TEXT NOT NULL,
        meaning_en TEXT,
        example TEXT,
        example_cn TEXT,
        level TEXT NOT NULL,
        category TEXT,
        image_url TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 用户学习记录表（SM-2 算法字段）
    db.run(`
      CREATE TABLE IF NOT EXISTS study_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        word_id INTEGER NOT NULL,
        repetitions INTEGER DEFAULT 0,
        interval_days INTEGER DEFAULT 1,
        ease_factor REAL DEFAULT 2.5,
        last_review DATETIME DEFAULT CURRENT_TIMESTAMP,
        next_review DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'learning',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (word_id) REFERENCES words(id),
        UNIQUE(user_id, word_id)
      )
    `);

    // 学习统计表
    db.run(`
      CREATE TABLE IF NOT EXISTS study_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        date DATE NOT NULL,
        words_learned INTEGER DEFAULT 0,
        words_reviewed INTEGER DEFAULT 0,
        study_time_minutes INTEGER DEFAULT 0,
        accuracy_rate REAL DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(id),
        UNIQUE(user_id, date)
      )
    `);

    // 插入示例单词数据
    const sampleWords = [
      ['abandon', '/əˈbændən/', '放弃；遗弃', 'to give up completely', 'He abandoned the plan.', '他放弃了这个计划。', 'CET4', '基础词汇'],
      ['abundant', '/əˈbʌndənt/', '丰富的；充裕的', 'existing in large quantities', 'The region has abundant natural resources.', '这个地区拥有丰富的自然资源。', 'CET4', '形容词'],
      ['access', '/ˈækses/', '进入；使用权', 'the right or opportunity to use', 'Students have access to the library.', '学生可以使用图书馆。', 'CET4', '名词'],
      ['accommodate', '/əˈkɒmədeɪt/', '容纳；提供住宿', 'to provide room for', 'The hotel can accommodate 500 guests.', '这家酒店可容纳500名客人。', 'CET6', '动词'],
      ['accurate', '/ˈækjərət/', '准确的；精确的', 'free from mistakes', 'The data must be accurate.', '数据必须准确。', 'CET4', '形容词'],
      ['achieve', '/əˈtʃiːv/', '达到；完成', 'to successfully complete', 'She achieved her goal.', '她实现了自己的目标。', 'CET4', '动词'],
      ['acquire', '/əˈkwaɪər/', '获得；取得', 'to gain or come to possess', 'He acquired a good reputation.', '他获得了良好的声誉。', 'CET6', '动词'],
      ['adapt', '/əˈdæpt/', '适应；改编', 'to adjust to new conditions', 'Plants adapt to their environment.', '植物会适应环境。', 'CET4', '动词'],
      ['adequate', '/ˈædɪkwət/', '足够的；适当的', 'sufficient for a specific need', 'The supply is adequate.', '供应是充足的。', 'CET6', '形容词'],
      ['adjacent', '/əˈdʒeɪsənt/', '相邻的；邻近的', 'next to or adjoining something', 'The two buildings are adjacent.', '这两栋建筑相邻。', 'CET6', '形容词'],
      ['adverse', '/ˈædvɜːrs/', '不利的；有害的', 'preventing success', 'Adverse weather delayed the flight.', '恶劣天气延误了航班。', 'CET6', '形容词'],
      ['advocate', '/ˈædvəkeɪt/', '提倡；拥护', 'to publicly support something', 'She advocates for education reform.', '她倡导教育改革。', 'CET6', '动词'],
      ['aesthetic', '/iːsˈθetɪk/', '审美的；美学的', 'concerned with beauty or artistic taste', 'The building has great aesthetic value.', '这栋建筑具有很高的审美价值。', 'CET6', '形容词'],
      ['ambiguous', '/æmˈbɪɡjuəs/', '模糊的；含糊的', 'open to more than one interpretation', 'His answer was ambiguous.', '他的回答含糊不清。', 'CET6', '形容词'],
      ['ambitious', '/æmˈbɪʃəs/', '有雄心的；有抱负的', 'having a strong desire for success', 'She is an ambitious young lawyer.', '她是一位有抱负的年轻律师。', 'CET4', '形容词'],
      ['apparent', '/əˈpærənt/', '明显的；表面上的', 'clear or obvious', 'The problem is apparent to everyone.', '这个问题对每个人来说都很明显。', 'CET4', '形容词'],
      ['appeal', '/əˈpiːl/', '呼吁；吸引；上诉', 'to make a serious request', 'The design appeals to young people.', '这个设计吸引年轻人。', 'CET4', '动词'],
      ['appetite', '/ˈæpɪtaɪt/', '食欲；渴望', 'physical desire for food', 'Exercise improves your appetite.', '运动能增进你的食欲。', 'CET6', '名词'],
      ['applaud', '/əˈplɔːd/', '鼓掌；称赞', 'to show approval by clapping', 'The audience applauded loudly.', '观众大声鼓掌。', 'CET6', '动词'],
      ['appreciate', '/əˈpriːʃieɪt/', '欣赏；感激；理解', 'to recognize the value of', 'I appreciate your help.', '我感谢你的帮助。', 'CET4', '动词'],
    ];

    const insertWord = db.prepare(`
      INSERT OR IGNORE INTO words (word, phonetic, meaning_cn, meaning_en, example, example_cn, level, category)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    sampleWords.forEach(w => insertWord.run(w));
    insertWord.finalize(() => {
      db.get('SELECT COUNT(*) as cnt FROM words', (err, row) => {
        if (row && row.cnt < 100) {
          console.log(`Word count: ${row.cnt}, seeding more words...`);
          seedMoreWords();
        }
      });
    });

    console.log('Database initialized.');
  });
}

// 补充更多单词
function seedMoreWords() {
  const moreWords = [
    ['appropriate', '/əˈproʊpriət/', '适当的；恰当的', 'suitable or fitting', 'Choose appropriate language.', '选择合适的语言。', 'CET6', '形容词'],
    ['approve', '/əˈpruːv/', '批准；赞成', 'to officially agree to something', 'The plan was approved.', '计划获得了批准。', 'CET4', '动词'],
    ['arise', '/əˈraɪz/', '出现；产生', 'to happen or occur', 'A problem may arise.', '可能会出现问题。', 'CET4', '动词'],
    ['arouse', '/əˈraʊz/', '引起；唤醒', 'to cause an emotion or attitude', 'The speech aroused public interest.', '这次演讲引起了公众的兴趣。', 'CET6', '动词'],
    ['aspect', '/ˈæspekt/', '方面；层面', 'a particular part of a situation', 'Consider every aspect.', '考虑每个方面。', 'CET4', '名词'],
    ['assemble', '/əˈsembl/', '集合；装配', 'to bring together into a group', 'We assembled at the gate.', '我们在大门口集合。', 'CET4', '动词'],
    ['assert', '/əˈsɜːrt/', '断言；主张', 'to state firmly', 'He asserted his innocence.', '他坚称自己无罪。', 'CET6', '动词'],
    ['assess', '/əˈses/', '评估；估价', 'to evaluate or estimate', 'We need to assess the risk.', '我们需要评估风险。', 'CET6', '动词'],
    ['assign', '/əˈsaɪn/', '分配；指派', 'to give someone a task', 'The teacher assigned homework.', '老师布置了作业。', 'CET4', '动词'],
    ['assist', '/əˈsɪst/', '协助；帮助', 'to help someone', 'She assisted me with the project.', '她协助我完成这个项目。', 'CET4', '动词'],
    ['assume', '/əˈsuːm/', '假设；认为', 'to suppose something is true', 'I assume you agree.', '我假设你同意。', 'CET4', '动词'],
    ['assure', '/əˈʃʊr/', '保证；使确信', 'to promise something confidently', 'I assure you it is safe.', '我向你保证这很安全。', 'CET6', '动词'],
    ['attain', '/əˈteɪn/', '达到；获得', 'to succeed in achieving something', 'He attained his goal.', '他达到了目标。', 'CET6', '动词'],
    ['attempt', '/əˈtempt/', '尝试；试图', 'to make an effort to do something', 'She attempted to solve the problem.', '她试图解决这个问题。', 'CET4', '动词'],
    ['attend', '/əˈtend/', '参加；出席', 'to be present at an event', 'Please attend the meeting.', '请参加会议。', 'CET4', '动词'],
    ['attitude', '/ˈætɪtuːd/', '态度；看法', 'a way of thinking or feeling', 'His attitude has changed.', '他的态度改变了。', 'CET4', '名词'],
    ['attract', '/əˈtrækt/', '吸引；引起', 'to cause interest or admiration', 'The show attracts many visitors.', '这场展览吸引了许多游客。', 'CET4', '动词'],
    ['authority', '/əˈθɔːrəti/', '权威；当局', 'the power to give orders', 'The authority decided to close the road.', '当局决定关闭这条道路。', 'CET6', '名词'],
    ['automatic', '/ˌɔːtəˈmætɪk/', '自动的', 'working by itself', 'The door is automatic.', '这扇门是自动的。', 'CET4', '形容词'],
    ['available', '/əˈveɪləbl/', '可用的；有空的', 'able to be used', 'The manager is available now.', '经理现在有空。', 'CET4', '形容词'],
  ];

  const insertWord = db.prepare(`
    INSERT OR IGNORE INTO words (word, phonetic, meaning_cn, meaning_en, example, example_cn, level, category)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  moreWords.forEach(w => insertWord.run(w));
  insertWord.finalize();
}

module.exports = { db, initDB };
