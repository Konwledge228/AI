// cache-helper.js - 网站数据缓存助手
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CACHE_DIR = path.join(__dirname, 'cache');
const CACHE_TTL = 86400000; // 24小时

// 确保缓存目录存在
if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

// 生成缓存键
function generateCacheKey(req) {
  const data = `${req.method}:${req.originalUrl}:${JSON.stringify(req.body)}`;
  return crypto.createHash('md5').update(data).digest('hex');
}

// 获取缓存文件路径
function getCacheFilePath(key) {
  return path.join(CACHE_DIR, `${key}.json`);
}

// 读取缓存
function getCache(req) {
  try {
    const key = generateCacheKey(req);
    const filePath = getCacheFilePath(key);
    
    if (!fs.existsSync(filePath)) {
      return null;
    }
    
    const cacheData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const now = Date.now();
    
    // 检查缓存是否过期
    if (now - cacheData.timestamp > CACHE_TTL) {
      fs.unlinkSync(filePath); // 删除过期缓存
      return null;
    }
    
    console.log(`[Cache] HIT: ${req.originalUrl}`);
    return cacheData.data;
  } catch (err) {
    console.error('[Cache] Read error:', err);
    return null;
  }
}

// 写入缓存
function setCache(req, data) {
  try {
    const key = generateCacheKey(req);
    const filePath = getCacheFilePath(key);
    
    const cacheData = {
      timestamp: Date.now(),
      data: data
    };
    
    fs.writeFileSync(filePath, JSON.stringify(cacheData, null, 2));
    console.log(`[Cache] SET: ${req.originalUrl}`);
    return true;
  } catch (err) {
    console.error('[Cache] Write error:', err);
    return false;
  }
}

// 清除缓存（按模式）
function clearCache(pattern = null) {
  try {
    const files = fs.readdirSync(CACHE_DIR);
    let cleared = 0;
    
    files.forEach(file => {
      if (file.endsWith('.json') && file !== 'README.md') {
        if (!pattern || file.includes(pattern)) {
          fs.unlinkSync(path.join(CACHE_DIR, file));
          cleared++;
        }
      }
    });
    
    console.log(`[Cache] Cleared ${cleared} files`);
    return cleared;
  } catch (err) {
    console.error('[Cache] Clear error:', err);
    return 0;
  }
}

// 缓存中间件（用于GET请求）
function cacheMiddleware(req, res, next) {
  // 只缓存GET请求
  if (req.method !== 'GET') {
    return next();
  }
  
  const cachedData = getCache(req);
  if (cachedData) {
    return res.json(cachedData);
  }
  
  // 重写res.json以捕获响应并缓存
  const originalJson = res.json.bind(res);
  res.json = function(data) {
    // 只缓存成功响应
    if (data && !data.error) {
      setCache(req, data);
    }
    return originalJson(data);
  };
  
  next();
}

// 清除缓存中间件（用于POST/PUT/DELETE请求后）
function clearCacheAfterChange(pattern) {
  return (req, res, next) => {
    const originalJson = res.json.bind(res);
    res.json = function(data) {
      // 如果操作成功，清除相关缓存
      if (data && !data.error) {
        clearCache(pattern);
      }
      return originalJson(data);
    };
    next();
  };
}

module.exports = {
  getCache,
  setCache,
  clearCache,
  cacheMiddleware,
  clearCacheAfterChange,
  generateCacheKey
};
