// create-admin.js - 生成随机管理员账号并存储
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'data', 'wordmaster.db');
const configPath = path.join(__dirname, '.admin-config.json');

// 生成随机账号信息
function generateAdminCredentials() {
  const adjectives = ['Smart', 'Bright', 'Quick', 'Sharp', 'Clever', 'Wise', 'Fast', 'Strong'];
  const nouns = ['Admin', 'Master', 'Leader', 'Chief', 'Boss', 'Head', 'Captain', 'Director'];
  const randomAdj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
  const randomNum = Math.floor(Math.random() * 1000);
  
  const username = `admin_${randomAdj.toLowerCase()}${randomNoun.toLowerCase()}${randomNum}`;
  const email = `${username}@wordmaster.com`;
  const password = `Admin@${Math.random().toString(36).substring(2, 10)}${randomNum}`;
  
  return { username, email, password };
}

// 创建管理员账号
async function createAdmin() {
  const credentials = generateAdminCredentials();
  const { username, email, password } = credentials;
  
  console.log('正在生成管理员账号...');
  console.log('用户名:', username);
  console.log('邮箱:', email);
  console.log('密码:', password);
  
  // 连接数据库
  const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error('数据库连接失败:', err);
      process.exit(1);
    }
  });
  
  // 哈希密码
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(password, salt);
  
  // 插入管理员账号
  const sql = `INSERT OR REPLACE INTO users (username, email, password_hash, created_at) VALUES (?, ?, ?, datetime('now'))`;
  
  db.run(sql, [username, email, passwordHash], function(err) {
    if (err) {
      console.error('插入管理员账号失败:', err);
      db.close();
      process.exit(1);
    }
    
    console.log('\n✅ 管理员账号已创建！');
    console.log('用户ID:', this.lastID);
    
    // 保存到本地配置文件
    const config = {
      admin: {
        username,
        email,
        password,
        user_id: this.lastID,
        created_at: new Date().toISOString()
      },
      database: {
        path: dbPath,
        type: 'SQLite',
        tables: ['users', 'words', 'study_records', 'study_stats']
      },
      cache_config: {
        enabled: true,
        cache_dir: path.join(__dirname, 'cache'),
        session_timeout: 86400000 // 24小时
      }
    };
    
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    console.log('\n✅ 配置已保存到:', configPath);
    
    // 创建缓存目录
    const cacheDir = path.join(__dirname, 'cache');
    if (!fs.existsSync(cacheDir)) {
      fs.mkdirSync(cacheDir, { recursive: true });
      console.log('✅ 缓存目录已创建:', cacheDir);
    }
    
    // 创建缓存说明文件
    const readme = `# WordMaster 缓存目录

此目录用于存储网站数据缓存。

## 缓存内容
- 用户会话缓存
- 单词数据缓存
- 学习记录缓存
- API 响应缓存

## 清理缓存
可以安全删除此目录中的所有文件，系统会在需要时重新生成。

创建时间: ${new Date().toLocaleString('zh-CN')}
`;
    fs.writeFileSync(path.join(cacheDir, 'README.md'), readme);
    
    db.close();
    
    console.log('\n========== 管理员账号信息 ==========');
    console.log('用户名:', username);
    console.log('邮箱:', email);
    console.log('密码:', password);
    console.log('====================================\n');
    console.log('请保存好这些信息！配置文件已加密存储密码哈希值。');
  });
}

// 执行创建
createAdmin();
