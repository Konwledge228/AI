// routes/review.js - 复习路由（完整 SM-2 算法）
const express = require('express');
const router = express.Router();
const { db } = require('../db');
const auth = require('../middleware/auth');

// SM-2 算法实现
function sm2(repetitions, interval, easeFactor, quality) {
  // quality: 0=complete blackout, 3=difficult, 4=hint, 5=easy
  if (quality < 3) {
    return { repetitions: 0, interval: 1, easeFactor: Math.max(1.3, easeFactor - 0.2) };
  }
  let newRep = repetitions + 1;
  let newInterval;
  let newEF = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  newEF = Math.max(1.3, newEF);

  if (newRep === 1) newInterval = 1;
  else if (newRep === 2) newInterval = 6;
  else newInterval = Math.round(interval * newEF);

  return { repetitions: newRep, interval: newInterval, easeFactor: newEF };
}

// 获取待复习单词
router.get('/due', auth, (req, res) => {
  const now = new Date().toISOString();
  db.all(`
    SELECT w.*, sr.repetitions, sr.interval_days, sr.ease_factor, sr.status
    FROM study_records sr
    JOIN words w ON sr.word_id = w.id
    WHERE sr.user_id = ? AND sr.next_review <= ? AND sr.status != 'mastered'
    ORDER BY sr.next_review ASC
    LIMIT 50
  `, [req.user.id, now], (err, rows) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    res.json({ words: rows || [], count: rows ? rows.length : 0 });
  });
});

// 提交复习结果（quality: 0-5）
router.post('/answer', auth, (req, res) => {
  const { word_id, quality } = req.body;
  if (!word_id || quality === undefined) {
    return res.status(400).json({ error: '缺少参数' });
  }
  const q = Math.max(0, Math.min(5, +quality));

  db.get(
    'SELECT * FROM study_records WHERE user_id = ? AND word_id = ?',
    [req.user.id, word_id],
    (err, record) => {
      if (!record) return res.status(404).json({ error: '学习记录不存在' });

      const { repetitions, interval_days, ease_factor } = record;
      const result = sm2(repetitions, interval_days, ease_factor, q);
      const next = new Date(Date.now() + result.interval * 86400000).toISOString();
      const status = result.repetitions >= 5 ? 'mastered' : 'learning';

      db.run(
        `UPDATE study_records SET repetitions=?, interval_days=?, ease_factor=?, last_review=?, next_review=?, status=? WHERE id=?`,
        [result.repetitions, result.interval, result.easeFactor, new Date().toISOString(), next, status, record.id],
        () => {
          // 更新每日统计
          const today = new Date().toISOString().split('T')[0];
          db.run(`
            INSERT INTO study_stats (user_id, date, words_reviewed, accuracy_rate)
            VALUES (?, ?, 1, ?)
            ON CONFLICT(user_id, date) DO UPDATE SET
              words_reviewed = words_reviewed + 1,
              accuracy_rate = (accuracy_rate * (words_reviewed - 1) + ?) / words_reviewed
          `, [req.user.id, today, q >= 3 ? 100 : 0, q >= 3 ? 100 : 0], () => {
            res.json({ ok: true, next_review: next, interval: result.interval, status });
          });
        }
      );
    }
  );
});

// 获取复习统计数据
router.get('/stats', auth, (req, res) => {
  db.get(`
    SELECT
      SUM(CASE WHEN status='mastered' THEN 1 ELSE 0 END) as mastered,
      SUM(CASE WHEN status='learning' THEN 1 ELSE 0 END) as learning,
      SUM(CASE WHEN next_review <= datetime('now') AND status!='mastered' THEN 1 ELSE 0 END) as due_today,
      COUNT(*) as total
    FROM study_records WHERE user_id = ?
  `, [req.user.id], (err, stats) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    res.json({ stats: stats || { mastered: 0, learning: 0, due_today: 0, total: 0 } });
  });
});

module.exports = router;
