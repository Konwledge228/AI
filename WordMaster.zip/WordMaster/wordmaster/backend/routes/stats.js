// routes/stats.js - 数据统计路由
const express = require('express');
const router = express.Router();
const { db } = require('../db');
const auth = require('../middleware/auth');

// 获取总体统计
router.get('/overview', auth, (req, res) => {
  db.get(`
    SELECT
      COUNT(CASE WHEN status='mastered' THEN 1 END) as mastered,
      COUNT(CASE WHEN status='learning' THEN 1 END) as learning,
      COUNT(*) as total_words,
      AVG(CASE WHEN status!='mastered' THEN interval_days END) as avg_interval,
      MIN(next_review) as next_review
    FROM study_records WHERE user_id = ?
  `, [req.user.id], (err, study) => {
    if (err) return res.status(500).json({ error: '查询失败' });

    db.get(`
      SELECT
        SUM(words_learned) as total_learned,
        SUM(words_reviewed) as total_reviewed,
        SUM(study_time_minutes) as total_minutes,
        AVG(accuracy_rate) as avg_accuracy
      FROM study_stats WHERE user_id = ?
    `, [req.user.id], (err2, stats) => {
      res.json({
        study: study || {},
        stats: stats || {}
      });
    });
  });
});

// 获取每日学习数据（用于图表）
router.get('/daily', auth, (req, res) => {
  db.all(`
    SELECT date, words_learned, words_reviewed, study_time_minutes, accuracy_rate
    FROM study_stats
    WHERE user_id = ? AND date >= date('now', '-30 days')
    ORDER BY date ASC
  `, [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    res.json({ daily: rows || [] });
  });
});

// 记录学习时长
router.post('/log', auth, (req, res) => {
  const { words_learned = 0, study_time_minutes = 0 } = req.body;
  const today = new Date().toISOString().split('T')[0];

  db.run(`
    INSERT INTO study_stats (user_id, date, words_learned, study_time_minutes)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(user_id, date) DO UPDATE SET
      words_learned = words_learned + ?,
      study_time_minutes = study_time_minutes + ?
  `, [req.user.id, today, words_learned, study_time_minutes, words_learned, study_time_minutes], (err) => {
    if (err) return res.status(500).json({ error: '记录失败' });
    res.json({ ok: true });
  });
});

module.exports = router;
