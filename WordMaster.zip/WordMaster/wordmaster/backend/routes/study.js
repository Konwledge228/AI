// routes/study.js - 学习记录路由
const express = require('express');
const router = express.Router();
const { db } = require('../db');
const auth = require('../middleware/auth');

// 获取今日学习单词
router.get('/today', auth, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  db.all(`
    SELECT w.*, sr.status as study_status, sr.interval_days
    FROM words w
    LEFT JOIN study_records sr ON w.id = sr.word_id AND sr.user_id = ?
    WHERE sr.next_review <= datetime('now') OR sr.id IS NULL
    ORDER BY sr.next_review ASC NULLS LAST
    LIMIT 20
  `, [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    res.json({ words: rows || [] });
  });
});

// 记录学习结果（答对/答错）
router.post('/record', auth, (req, res) => {
  const { word_id, correct } = req.body;
  if (!word_id) return res.status(400).json({ error: '缺少单词ID' });

  const now = new Date().toISOString();
  // 查询现有记录
  db.get(
    'SELECT * FROM study_records WHERE user_id = ? AND word_id = ?',
    [req.user.id, word_id],
    (err, record) => {
      if (record) {
        // 更新现有记录
        let { repetitions, interval_days, ease_factor } = record;
        if (correct) {
          repetitions += 1;
          if (repetitions === 1) interval_days = 1;
          else if (repetitions === 2) interval_days = 6;
          else interval_days = Math.round(interval_days * ease_factor);
          ease_factor = Math.max(1.3, ease_factor + 0.1);
        } else {
          repetitions = 0;
          interval_days = 1;
          ease_factor = Math.max(1.3, ease_factor - 0.2);
        }
        const next = new Date(Date.now() + interval_days * 86400000).toISOString();
        db.run(
          `UPDATE study_records SET repetitions=?, interval_days=?, ease_factor=?, last_review=?, next_review=?, status='learning' WHERE id=?`,
          [repetitions, interval_days, ease_factor, now, next, record.id],
          () => res.json({ ok: true, next_review: next, interval_days })
        );
      } else {
        // 新建记录
        const interval = correct ? 1 : 1;
        const next = new Date(Date.now() + interval * 86400000).toISOString();
        db.run(
          `INSERT INTO study_records (user_id, word_id, repetitions, interval_days, ease_factor, last_review, next_review, status)
           VALUES (?, ?, ?, ?, 2.5, ?, ?, 'learning')`,
          [req.user.id, word_id, correct ? 1 : 0, interval, now, next],
          () => res.json({ ok: true, next_review: next, interval_days: interval })
        );
      }
    }
  );
});

module.exports = router;
