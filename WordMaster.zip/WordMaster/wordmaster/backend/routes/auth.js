// routes/auth.js - 用户认证路由
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../db');

const JWT_SECRET = process.env.JWT_SECRET || 'wordmaster_secret_key_2026';
const JWT_EXPIRES = process.env.JWT_EXPIRES_IN || '7d';

// 注册
router.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ error: '用户名、邮箱和密码均为必填项' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: '密码长度至少6位' });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  db.run(
    'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)',
    [username, email, passwordHash],
    function (err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(409).json({ error: '用户名或邮箱已被注册' });
        }
        return res.status(500).json({ error: '注册失败' });
      }
      const token = jwt.sign({ userId: this.lastID, username }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
      res.json({ token, user: { id: this.lastID, username, email } });
    }
  );
});

// 登录
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '请输入用户名和密码' });
  }

  db.get('SELECT * FROM users WHERE username = ? OR email = ?', [username, username], (err, user) => {
    if (err || !user) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    if (!bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    res.json({ token, user: { id: user.id, username: user.username, email: user.email } });
  });
});

// 获取当前用户
router.get('/me', (req, res) => {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: '未登录' });
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    db.get('SELECT id, username, email, created_at FROM users WHERE id = ?', [decoded.userId], (err, user) => {
      if (err || !user) return res.status(401).json({ error: '用户不存在' });
      res.json({ user });
    });
  } catch (e) {
    res.status(401).json({ error: '令牌无效或已过期' });
  }
});

module.exports = router;
