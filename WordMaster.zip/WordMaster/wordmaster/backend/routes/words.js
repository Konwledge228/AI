// routes/words.js - 单词库路由
const express = require('express');
const router = express.Router();
const { db } = require('../db');
const auth = require('../middleware/auth');

// 获取所有级别/分类
router.get('/levels', (req, res) => {
  db.all(
    'SELECT DISTINCT level, COUNT(*) as count FROM words GROUP BY level ORDER BY level',
    [], (err, rows) => {
      if (err) return res.status(500).json({ error: '查询失败' });
      res.json({ levels: rows });
    }
  );
});

// 获取单词列表（支持分页、级别筛选、搜索）
router.get('/', (req, res) => {
  const { level, search, page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;
  let sql = 'SELECT * FROM words WHERE 1=1';
  let params = [];

  if (level) { sql += ' AND level = ?'; params.push(level); }
  if (search) { sql += ' AND (word LIKE ? OR meaning_cn LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

  db.get(`SELECT COUNT(*) as total FROM (${sql})`, params, (err, countRow) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    sql += ' ORDER BY id LIMIT ? OFFSET ?';
    db.all(sql, [...params, +limit, +offset], (err2, rows) => {
      if (err2) return res.status(500).json({ error: '查询失败' });
      res.json({ words: rows, total: countRow.total, page: +page, limit: +limit });
    });
  });
});

// 获取单个单词详情
router.get('/:id', (req, res) => {
  db.get('SELECT * FROM words WHERE id = ?', [req.params.id], (err, word) => {
    if (err || !word) return res.status(404).json({ error: '单词不存在' });
    res.json({ word });
  });
});

// 获取用户学习进度中的单词（需登录）
router.get('/study/list', auth, (req, res) => {
  const { status } = req.query;
  let sql = `
    SELECT w.*, sr.repetitions, sr.interval_days, sr.next_review, sr.status as study_status
    FROM words w
    LEFT JOIN study_records sr ON w.id = sr.word_id AND sr.user_id = ?
    WHERE 1=1
  `;
  let params = [req.user.id];
  if (status) {
    sql += ' AND (sr.status = ? OR (sr.status IS NULL AND ? = "learning"))';
    params.push(status, status);
  }
  sql += ' ORDER BY sr.next_review ASC NULLS LAST, w.id ASC LIMIT 50';

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: '查询失败' });
    res.json({ words: rows });
  });
});

// 添加新单词（需登录）
router.post('/', auth, (req, res) => {
  const {
    word,
    phonetic,
    meaning_cn,
    meaning_en,
    example,
    example_cn,
    level,
    category,
    image_url
  } = req.body;

  // 验证必填字段
  if (!word || !meaning_cn || !level) {
    return res.status(400).json({ error: '单词、中文释义和级别为必填项' });
  }

  const sql = `
    INSERT INTO words (word, phonetic, meaning_cn, meaning_en, example, example_cn, level, category, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.run(sql, [word, phonetic, meaning_cn, meaning_en, example, example_cn, level, category, image_url], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint')) {
        return res.status(409).json({ error: '该单词已存在' });
      }
      return res.status(500).json({ error: '添加失败' });
    }
    res.json({
      success: true,
      message: '单词添加成功',
      word_id: this.lastID
    });
  });
});

// 删除单词（需登录，管理员功能）
router.delete('/:id', auth, (req, res) => {
  db.run('DELETE FROM words WHERE id = ?', [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: '删除失败' });
    if (this.changes === 0) return res.status(404).json({ error: '单词不存在' });
    
    // 同时删除相关的学习记录
    db.run('DELETE FROM study_records WHERE word_id = ?', [req.params.id]);
    
    res.json({ success: true, message: '单词删除成功' });
  });
});

module.exports = router;
