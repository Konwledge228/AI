// middleware/auth.js - JWT 认证中间件
const jwt = require('jsonwebtoken');
const { db } = require('../db');

module.exports = (req, res, next) => {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ error: '未提供认证令牌' });

  const token = header.split(' ')[1];
  if (!token) return res.status(401).json({ error: '令牌格式错误' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'wordmaster_secret_key_2026');
    // 查询用户是否存在
    db.get('SELECT id, username, email FROM users WHERE id = ?', [decoded.userId], (err, user) => {
      if (err || !user) return res.status(401).json({ error: '用户不存在或令牌无效' });
      req.user = user;
      next();
    });
  } catch (e) {
    return res.status(401).json({ error: '令牌已过期或无效' });
  }
};
