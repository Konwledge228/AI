// verify-admin.js - 验证管理员账号
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'data', 'wordmaster.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('数据库连接失败:', err);
    process.exit(1);
  }
});

console.log('正在查询数据库中的用户...\n');

db.all('SELECT id, username, email, created_at FROM users', [], (err, rows) => {
  if (err) {
    console.error('查询失败:', err);
  } else {
    console.log('========== 用户列表 ==========');
    rows.forEach(row => {
      console.log(`ID: ${row.id}`);
      console.log(`用户名: ${row.username}`);
      console.log(`邮箱: ${row.email}`);
      console.log(`创建时间: ${row.created_at}`);
      console.log('----------------------------');
    });
    console.log(`共 ${rows.length} 个用户`);
    console.log('==============================\n');
  }
  
  db.close();
});
