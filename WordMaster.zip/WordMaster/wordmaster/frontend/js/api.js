// api.js - 共享：认证检查 + API 调用封装

// 检查是否在 file:// 协议下打开
(function() {
  if (window.location.protocol === 'file:') {
    document.body.innerHTML = `
      <div style="font-family:sans-serif;max-width:600px;margin:50px auto;padding:20px;text-align:center;">
        <h1 style="color:#d32f2f;">⚠️ 访问方式错误</h1>
        <p style="font-size:16px;margin:20px 0;">
          请不要直接双击打开 HTML 文件！
        </p>
        <div style="background:#f5f5f5;padding:15px;border-radius:8px;margin:20px 0;text-align:left;">
          <h3>正确打开方式：</h3>
          <ol style="line-height:2;">
            <li>先双击 <strong>启动WordMaster.bat</strong></li>
            <li>或者手动在浏览器地址栏输入：
              <code style="background:#e0e0e0;padding:2px 6px;border-radius:4px;">http://localhost:3000/index.html</code>
            </li>
          </ol>
        </div>
        <button onclick="window.location.href='http://localhost:3000/index.html'" 
                style="padding:10px 20px;background:#1976d2;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px;">
          尝试跳转 to http://localhost:3000/index.html
        </button>
      </div>
    `;
    throw new Error('请在 http:// 协议下访问此页面');
  }
})();

const API = 'http://localhost:3000/api';

// 认证检查：未登录则跳转
function checkAuth() {
  const token = localStorage.getItem('wm_token');
  if (!token) { location.href = 'index.html'; return null; }
  return token;
}

// 通用 fetch 封装
async function apiCall(path, options = {}) {
  const token = localStorage.getItem('wm_token');
  const defaults = {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + (token || ''),
     },
   };
  const config = { ...defaults, ...options };
  if (config.body && typeof config.body === 'object') {
    config.body = JSON.stringify(config.body);
  }

  const res = await fetch(API + path, config);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || '请求失败');
  return data;
}

// 退出登录
function logout() {
  localStorage.removeItem('wm_token');
  localStorage.removeItem('wm_user');
  location.href = 'index.html';
}

// 获取当前用户
function getUser() {
  try { return JSON.parse(localStorage.getItem('wm_user')); } catch { return null; }
}

// 格式化时间
function formatTime(minutes) {
  if (minutes < 60) return minutes + ' 分钟';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? h + '小时' + m + '分钟' : h + '小时';
}

// 简单柱状图（纯 CSS/HTML 实现）
function renderBarChart(containerId, data, labelKey, valueKey, color) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const max = Math.max(...data.map(d => d[valueKey]), 1);
  container.innerHTML = data.map(d => {
    const h = Math.max(8, (d[valueKey] / max) * 120);
    return `
      <div style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;min-width:0">
        <div style="height:${h}px;width:100%;max-width:32px;background:${color||'rgba(120,119,198,0.7)'};
                     border-radius:6px 6px 2px 2px;transition:height 0.6s var(--spring-fast)"></div>
        <div style="font-size:11px;color:rgba(255,255,255,0.5);text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:48px">${d[labelKey]}</div>
        <div style="font-size:10px;color:rgba(255,255,255,0.35)">${d[valueKey]}</div>
      </div>`;
  }).join('');
}
