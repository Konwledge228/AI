@echo off
REM WordMaster 启动脚本 - 双击这个文件即可
title WordMaster 启动器

echo ================================================
echo          WordMaster 背单词系统启动器
echo ================================================
echo.

REM 设置路径
set BACKEND_DIR=C:\Users\李皓文\Desktop\Code\workbuddy\wordmaster\backend
set PORT=3000

echo [1/3] 检查 Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Node.js，请先安装 Node.js
    pause
    exit /b 1
)
echo [成功] Node.js 已安装
echo.

echo [2/3] 检查服务器状态...
netstat -ano | find ":%PORT%" | find "LISTENING" >nul 2>&1
if %errorlevel% equ 0 (
    echo [信息] 服务器已在运行
) else (
    echo [信息] 正在启动服务器...
    cd /d "%BACKEND_DIR%"
    start "WordMaster Backend" /min node server.js
    timeout /t 3 /nobreak >nul
    echo [成功] 服务器已启动
)
echo.

echo [3/3] 打开浏览器...
start http://localhost:%PORT%/index.html
echo.

echo ================================================
echo  成功！浏览器应该已打开 WordMaster 登录页面
echo  如果没有，请手动访问：http://localhost:%PORT%/index.html
echo ================================================
echo.
timeout /t 5 /nobreak >nul
