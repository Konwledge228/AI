# WordMaster — 智能背单词平台

> 液态玻璃风格 · 前后端分离 · AI 辅助学习

## 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | HTML5 + CSS3（液态玻璃特效）+ Vanilla JS |
| 后端 | Node.js + Express + SQLite |
| 认证 | JWT（jsonwebtoken）|
| 加密 | bcryptjs |
| 算法 | SM-2 间隔重复算法 |

## 快速启动

### 1. 安装后端依赖
```bash
cd wordmaster/backend
npm install
```

### 2. 启动后端服务
```bash
node server.js
# 默认运行在 http://localhost:3000
```

### 3. 访问网站
浏览器打开 http://localhost:3000/index.html

## 功能模块

### ✅ 已实现
- 🔐 用户注册 / 登录（JWT 认证）
- 🃏 单词卡片背诵（正面单词 / 点击翻转查看释义）
- 📊 艾宾浩斯智能复习（SM-2 算法，0-5 质量评分）
- 📈 学习数据统计（每日学习量、正确率、学习时长）
- 🔘 单词库（CET4 / CET6，可扩展）
- 🎨 液态玻璃 UI（Q 弹动效、spring 缓动、模糊玻璃面板）

### 🚧 待扩展
- 第三方登录（Google / GitHub）
- AI 生成例句（接入 LLM API）
- 单词图片辅助记忆
- 多端适配（PWA / 移动端）

## 数据库

SQLite 数据库文件：`backend/data/wordmaster.db`（自动创建）

表结构：
- `users` — 用户账号
- `words` — 单词库
- `study_records` — 学习记录（含 SM-2 字段）
- `study_stats` — 每日学习统计

## 项目结构

```
wordmaster/
├── backend/
│   ├── server.js          # Express 主入口
│   ├── db.js              # SQLite 初始化 + 种子数据
│   ├── package.json
│   ├── .env
│   ├── middleware/
│   │   └── auth.js       # JWT 验证中间件
│   ├── routes/
│   │   ├── auth.js       # 注册 / 登录
│   │   ├── words.js      # 单词查询
│   │   ├── study.js      # 学习记录
│   │   ├── review.js     # 复习（SM-2）
│   │   └── stats.js      # 学习统计
│   └── data/
│       └── wordmaster.db
└── frontend/
    ├── index.html         # 登录 / 注册
    ├── dashboard.html     # 仪表盘
    ├── study.html         # 背单词卡片
    ├── review.html        # 智能复习
    ├── stats.html         # 学习统计
    ├── css/
    │   └── liquid-glass.css  # 液态玻璃样式系统
    └── js/
        └── api.js        # 共享 API 调用
```

## API 接口一览

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/auth/register` | 注册 |
| POST | `/api/auth/login` | 登录 |
| GET | `/api/auth/me` | 获取当前用户 |
| GET | `/api/words?level=CET4` | 单词列表 |
| GET | `/api/words/levels` | 所有级别 |
| GET | `/api/words/study/list` | 学习用单词列表 |
| POST | `/api/study/record` | 记录学习结果 |
| GET | `/api/review/due` | 待复习单词 |
| POST | `/api/review/answer` | 提交复习评分 |
| GET | `/api/review/stats` | 复习统计 |
| GET | `/api/stats/overview` | 总体统计 |
| GET | `/api/stats/daily` | 每日数据 |

---
*由 WorkBuddy AI 生成 · 2026-05-09*
